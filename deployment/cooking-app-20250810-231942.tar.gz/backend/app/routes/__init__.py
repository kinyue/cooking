# backend/app/routes/__init__.py
# Blueprint initialization
